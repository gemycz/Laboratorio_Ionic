import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the WebServicesProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class WebServicesProvider {

  url= "http://localhost:3000/";
  constructor(public https: HttpClient, public http: HttpClient) {
    
  }


getUserByCedula(cedula: String){
  return new Promise(resolve=>{
    this.http.get(this.url+'usuario/'+cedula).subscribe(data=>{
      resolve(data);
    }, err =>{
      console.log(err);
    });
  });
}

getUser(){
  return new Promise(resolve=>{
    this.http.get(this.url+'usuario').subscribe(data=>{
      resolve(data);
    }, err =>{
      console.log(err);
    });
  });
}


saveUsuario(data){
  console.log(JSON.stringify(data));
  return new Promise ((resolve, reject)=>{
    this.https.post(this.url+'usuario', data).subscribe(res=>{
      resolve(res);
      console.log(JSON.stringify(data));
    }, err =>{
      reject(err);
    });
  });
}

}
