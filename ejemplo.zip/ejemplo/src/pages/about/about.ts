import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { WebServicesProvider } from '../../providers/web-services/web-services';
import { AlertController } from 'ionic-angular';
import { HomePage } from '../home/home';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {

  private cedula: string;
  private nombre: string;
  private apellido: string;
  private direccion: string;
  private telefono: string;
  private correo: string;


  constructor(
    public navCtrl: NavController,
    public WebServicesProvider: WebServicesProvider, 
    public alertCtrl: AlertController) {
  

  }

  async guardarUsuarioBD(){
    try {
      let newUsuario = this.construirYObtenerUsuarioNuevo();
      await this.WebServicesProvider.saveUsuario(newUsuario);
      this.showAlert("Guardado con éxito");
    } catch (error) {
      console.log(error);
      this.showAlert("Ocurrio un error");
    }
  }

  construirYObtenerUsuarioNuevo(){
    let newUsuario={
      nombreusuario:this.nombre,
        apellidousuario:this.apellido,
        cedulausuario: this.cedula,
        telefonousuario: this.telefono,
        direccionusuario: this.direccion,
        correousuario: this.correo
    }
    return newUsuario;
  }

  showAlert(alertText:string) {
    const alert = this.alertCtrl.create({
      title: '<center>Informacion</center>',
      subTitle: alertText,
      buttons: [
        {
          text: 'Aceptar', 
          handler: ()=> {
            this.regresarHome();
          }
        }
      ]
    }).present();
  }

  regresarHome(){
   // this.navCtrl.push(HomePage);
   this.navCtrl.parent.select(0);
  }


}
