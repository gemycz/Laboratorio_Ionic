import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { WebServicesProvider } from '../../providers/web-services/web-services';
 
@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
 
  private usuarios:any;
 
 
  constructor(
    public navCtrl: NavController,
    public WebServicesProvider: WebServicesProvider) {
 
  }
  
  ionViewDidLoad() {
    this.cargarUsuarios();
  }
 
  cargarUsuarios(){
    this.WebServicesProvider.getUser().then(data =>{
      this.usuarios = data;
    })
  }
 
}

