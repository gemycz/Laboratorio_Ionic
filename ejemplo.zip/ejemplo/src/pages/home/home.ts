import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { WebServicesProvider } from '../../providers/web-services/web-services';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  private usuario:any;
  private cedula:String;
  private nombre:String;
  private apellido: String;
  private direccion: String;
  private correo: String;
  private telefono: String;

  constructor(public navCtrl: NavController,
    public webServicesProvider: WebServicesProvider ) {

  }

  async getUsuarioByCedula(){
    try {
      this.usuario = await this.webServicesProvider.getUserByCedula(this.cedula);
      console.log(this.usuario);
      this.nombre = this.usuario[0].nombreusuario;
      this.apellido = this.usuario[0].apellidousuario;
      this.direccion = this.usuario[0].direccionusuario;
      this.correo = this.usuario[0].correousuario;
      this.telefono = this.usuario[0].telefonousuario;
    } catch (error) {
      console.log(error);
    }
  }

}
